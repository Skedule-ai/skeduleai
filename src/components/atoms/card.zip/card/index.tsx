import React from 'react';
import { CardProps, cardVariants } from './card.variants';
import CardLoader from '@/components/organisms/loader/CardLoader';

type ExtendedCardProps = CardProps & {
    loading?: boolean;
};

const Card = React.forwardRef<HTMLDivElement, ExtendedCardProps>(
    ({ as = 'div', size, variant, className, children, loading = false, ...rest }, ref) => {
        if (loading) {
            return <CardLoader />;
        }

        return React.createElement(
            as,
            {
                ...rest,
                className: cardVariants({ size, variant, className }),
                ref,
            },
            children,
        );
    },
);

export default Card;
